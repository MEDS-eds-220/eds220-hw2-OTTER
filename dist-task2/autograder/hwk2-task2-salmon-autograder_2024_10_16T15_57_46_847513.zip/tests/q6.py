OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> len(catch_1) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> catch_1.iloc[0] == 'GSE'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> bool(catch_1.iloc[1] == 1955)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> catch_1.iloc[3] == 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
