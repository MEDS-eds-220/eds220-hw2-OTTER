OK_FORMAT = True

test = {   'name': 'q2b',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> pd.read_csv('data/t2_q2_df.csv', index_col=None).equals(catch_data)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
