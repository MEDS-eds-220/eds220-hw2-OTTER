OK_FORMAT = True

test = {'name': 'q2a', 'points': 2, 'suites': [{'cases': [{'code': '>>> len(notes_unique) == 30\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
