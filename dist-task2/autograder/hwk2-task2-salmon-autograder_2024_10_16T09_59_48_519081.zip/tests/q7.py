OK_FORMAT = True

test = {'name': 'q7', 'points': 2, 'suites': [{'cases': [{'code': '>>> \n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
