from otter.test_files import test_case

OK_FORMAT = False

name = "q4"
points = 2

@test_case(points=None, hidden=False)
def frames_are_equal(df1, df2):
    try:
        pd.testing.assert_frame_equal(df1, df2)
        return True  # No exception means DataFrames are equal
    except AssertionError:
        return False 
        
@test_case(points=None, hidden=False)
def frames_are_equal(df1, df2):
    pd.testing.assert_frame_equal(df1, df2.reset_index(drop=True))
        
@test_case(points=None, hidden=False)
assert pd.read_csv('data/t3_q4_df.csv').equals(aqi.reset_index(drop=True))
@test_case(points=None, hidden=False)
pd.testing.assert_frame_equal(pd.read_csv('data/t3_q4_df.csv'), 
                              aqi.reset_index(drop=True))
