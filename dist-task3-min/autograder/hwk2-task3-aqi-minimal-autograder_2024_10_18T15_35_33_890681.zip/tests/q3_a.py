from otter.test_files import test_case

OK_FORMAT = False

name = "q3_a"
points = 2

@test_case(points=None, hidden=False)
assert pd.read_csv('data/t3_q3a_df.csv').equals(aqi_17_head)
