from otter.test_files import test_case

OK_FORMAT = False

name = "q5"
points = 3

@test_case(points=None, hidden=False)
assert aqi.equals(aqi)
