OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> pd.read_csv('data/t3_q4_df.csv', index_col=False).equals(aqi)\nFalse", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
