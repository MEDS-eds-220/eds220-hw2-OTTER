OK_FORMAT = True

test = {'name': 'q6_c', 'points': 2, 'suites': [{'cases': [{'code': '>>> date_type is pd.Series\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
