OK_FORMAT = True

test = {   'name': 'q3_a',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> assert pd.read_csv('data/t3_q3a_df.csv').equals(aqi_17_head)\n", 'hidden': True, 'locked': False},
                                   {'code': ">>> assert pd.read_csv('data/t3_q3b_df.csv').equals(aqi_18_head)\n", 'hidden': True, 'locked': False},
                                   {'code': '>>> \n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
