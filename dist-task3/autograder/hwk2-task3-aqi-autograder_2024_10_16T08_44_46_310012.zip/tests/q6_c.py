OK_FORMAT = True

test = {   'name': 'q6_c',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> with open('data/t3_q6c_df.txt', 'r') as file:\n...     type_txt = file.read()\n>>> type_txt == str(date_type)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
